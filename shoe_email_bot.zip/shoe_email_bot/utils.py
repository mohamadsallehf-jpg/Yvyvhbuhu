"""
توابع کمکی: رمزنگاری پسورد SMTP، هش PIN، رندر قالب، پارس CSV مخاطبین
"""
import csv
import hashlib
import io
import re

from cryptography.fernet import Fernet
from email_validator import validate_email, EmailNotValidError

from config import ENCRYPTION_KEY

_fernet = Fernet(ENCRYPTION_KEY.encode() if isinstance(ENCRYPTION_KEY, str) else ENCRYPTION_KEY)

MERGE_TAG_PATTERN = re.compile(r"\{(name|email)\}")


# ---------------------------------------------------------------------------
# رمزنگاری پسورد SMTP (هیچوقت پسورد خام تو دیتابیس ذخیره نمیشه)
# ---------------------------------------------------------------------------

def encrypt_password(raw_password: str) -> str:
    return _fernet.encrypt(raw_password.encode()).decode()


def decrypt_password(encrypted_password: str) -> str:
    return _fernet.decrypt(encrypted_password.encode()).decode()


# ---------------------------------------------------------------------------
# هش PIN کد ادمین (برای تایید عملیات حساس مثل ارسال کمپین یا حذف مخاطبین)
# ---------------------------------------------------------------------------

def hash_pin(pin: str) -> str:
    return hashlib.sha256(pin.encode()).hexdigest()


def verify_pin(pin: str, hashed: str) -> bool:
    return hash_pin(pin) == hashed


# ---------------------------------------------------------------------------
# اعتبارسنجی ایمیل
# ---------------------------------------------------------------------------

def is_valid_email(email: str) -> bool:
    try:
        validate_email(email, check_deliverability=False)
        return True
    except EmailNotValidError:
        return False


# ---------------------------------------------------------------------------
# رندر قالب با تگ‌های شخصی‌سازی مثل {name} و {email}
# ---------------------------------------------------------------------------

def render_template(html_body: str, subject: str, contact_name: str, contact_email: str):
    def repl(match):
        key = match.group(1)
        if key == "name":
            return contact_name or "مشتری عزیز"
        if key == "email":
            return contact_email
        return match.group(0)

    rendered_html = MERGE_TAG_PATTERN.sub(repl, html_body)
    rendered_subject = MERGE_TAG_PATTERN.sub(repl, subject)
    return rendered_subject, rendered_html


def append_unsubscribe_footer(html_body: str, unsubscribe_token: str, unsubscribe_base_url: str = "") -> str:
    """
    چون پنل فقط داخل تلگرامه و سرور وب جداگانه‌ای نداریم، لینک لغو اشتراک
    به صورت mailto با موضوع خاص ساخته میشه تا کاربر با ریپلای بتونه لغو کنه؛
    اگر بعدا دامنه و وب‌سرور اضافه کردی، unsubscribe_base_url رو ست کن تا لینک HTTP واقعی بسازه.
    """
    if unsubscribe_base_url:
        link = f"{unsubscribe_base_url}?token={unsubscribe_token}"
    else:
        link = f"mailto:unsubscribe@yourshop.com?subject=UNSUB-{unsubscribe_token}"

    footer = f"""
    <hr style="margin-top:24px;border:none;border-top:1px solid #eee;">
    <p style="font-size:11px;color:#999;text-align:center;">
        اگر مایل به دریافت این ایمیل‌ها نیستید،
        <a href="{link}" style="color:#999;">اینجا کلیک کنید</a> برای لغو اشتراک.
    </p>
    """
    return html_body + footer


# ---------------------------------------------------------------------------
# پارس فایل CSV مخاطبین (ستون‌های email و name)
# ---------------------------------------------------------------------------

def parse_contacts_csv(file_bytes: bytes):
    """
    برمی‌گردونه: (لیست دیکشنری‌های معتبر [{email, name}], لیست خطاها)
    فایل باید حداقل ستون email داشته باشه، ستون name اختیاریه.
    """
    valid_rows = []
    errors = []

    text = file_bytes.decode("utf-8-sig", errors="ignore")
    reader = csv.DictReader(io.StringIO(text))

    if reader.fieldnames is None:
        return [], ["فایل CSV خالی یا نامعتبر است."]

    normalized_fields = {f.lower().strip(): f for f in reader.fieldnames}
    email_col = normalized_fields.get("email")
    name_col = normalized_fields.get("name") or normalized_fields.get("full_name")

    if not email_col:
        return [], ["ستون 'email' در فایل CSV پیدا نشد. حتما یک ستون به نام email داشته باش."]

    for i, row in enumerate(reader, start=2):
        email = (row.get(email_col) or "").strip()
        name = (row.get(name_col) or "").strip() if name_col else ""

        if not email:
            continue
        if not is_valid_email(email):
            errors.append(f"ردیف {i}: ایمیل نامعتبر ({email})")
            continue

        valid_rows.append({"email": email.lower(), "name": name})

    return valid_rows, errors
