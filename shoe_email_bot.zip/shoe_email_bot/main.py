"""
نقطه ورود اصلی ربات
اجرا: python main.py
"""
import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN, SUPER_ADMIN_TELEGRAM_ID
from database import init_db
from handlers import campaigns, contacts, dashboard, security, smtp_settings, start, templates
from middleware import AdminAuthMiddleware
from scheduler import start_scheduler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger("main")


async def main():
    logger.info("راه‌اندازی دیتابیس...")
    init_db(SUPER_ADMIN_TELEGRAM_ID)

    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())

    # میان‌افزار امنیتی روی همه‌ی آپدیت‌ها (پیام و کلیک دکمه) اعمال میشه
    dp.message.middleware(AdminAuthMiddleware())
    dp.callback_query.middleware(AdminAuthMiddleware())

    dp.include_router(start.router)
    dp.include_router(dashboard.router)
    dp.include_router(contacts.router)
    dp.include_router(templates.router)
    dp.include_router(campaigns.router)
    dp.include_router(smtp_settings.router)
    dp.include_router(security.router)

    logger.info("راه‌اندازی زمان‌بند کمپین‌ها...")
    start_scheduler()

    logger.info("ربات در حال اجراست...")
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("ربات متوقف شد.")
