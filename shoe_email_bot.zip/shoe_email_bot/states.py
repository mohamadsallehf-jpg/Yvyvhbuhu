"""
حالت‌های مکالمه (FSM) برای فلوهای چند مرحله‌ای ربات
"""
from aiogram.fsm.state import State, StatesGroup


class ContactStates(StatesGroup):
    waiting_email = State()
    waiting_name = State()
    waiting_csv_file = State()
    waiting_search_query = State()
    waiting_tag_to_add = State()


class TemplateStates(StatesGroup):
    waiting_name = State()
    waiting_subject = State()
    waiting_html_body = State()
    waiting_edit_field = State()


class CampaignStates(StatesGroup):
    waiting_name = State()
    choosing_template = State()
    choosing_tag_filter = State()
    choosing_smtp_account = State()
    choosing_schedule = State()
    waiting_custom_datetime = State()
    waiting_pin_confirm = State()


class SMTPStates(StatesGroup):
    waiting_name = State()
    waiting_host = State()
    waiting_port = State()
    waiting_username = State()
    waiting_password = State()
    waiting_from_name = State()
    waiting_from_email = State()
    waiting_daily_limit = State()
    waiting_rate_limit = State()


class SecurityStates(StatesGroup):
    waiting_new_admin_id = State()
    waiting_pin_setup = State()
    waiting_pin_verify = State()
