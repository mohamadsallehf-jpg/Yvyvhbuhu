"""
مدیریت مخاطبین: افزودن دستی، ایمپورت CSV، جستجو، لیست صفحه‌بندی‌شده،
خروجی CSV، تگ‌گذاری و حذف
"""
import csv
import io

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import BufferedInputFile, CallbackQuery, Message

from database import get_session
from keyboards import (back_btn, contact_detail_kb, contacts_menu_kb,
                        pagination_kb, yes_no_kb)
from models import Contact, Tag
from states import ContactStates
from utils import is_valid_email, parse_contacts_csv

router = Router(name="contacts")

PAGE_SIZE = 10


@router.callback_query(F.data == "menu:contacts")
async def contacts_menu(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await callback.message.edit_text("👥 مدیریت مخاطبین:", reply_markup=contacts_menu_kb())
    await callback.answer()


# ---------------------------------------------------------------------------
# افزودن دستی مخاطب
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "contacts:add")
async def start_add_contact(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(ContactStates.waiting_email)
    await callback.message.edit_text(
        "📧 ایمیل مخاطب جدید رو بفرست:",
        reply_markup=back_btn("menu:contacts"),
    )
    await callback.answer()


@router.message(ContactStates.waiting_email)
async def receive_contact_email(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    email = message.text.strip().lower()
    if not is_valid_email(email):
        await message.answer("❌ این ایمیل معتبر نیست. دوباره امتحان کن:")
        return

    session = get_session()
    try:
        if session.query(Contact).filter_by(email=email).first():
            await message.answer("⚠️ این ایمیل قبلا تو لیست هست.", reply_markup=contacts_menu_kb())
            await state.clear()
            return
    finally:
        session.close()

    await state.update_data(email=email)
    await state.set_state(ContactStates.waiting_name)
    await message.answer("👤 حالا اسم مخاطب رو بفرست (یا برای رد شدن، فقط - بفرست):")


@router.message(ContactStates.waiting_name)
async def receive_contact_name(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    name = "" if message.text.strip() == "-" else message.text.strip()
    data = await state.get_data()

    session = get_session()
    try:
        contact = Contact(email=data["email"], full_name=name, source="manual")
        session.add(contact)
        session.commit()
    finally:
        session.close()

    await state.clear()
    await message.answer(f"✅ مخاطب «{data['email']}» اضافه شد.", reply_markup=contacts_menu_kb())


# ---------------------------------------------------------------------------
# ایمپورت از CSV
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "contacts:import")
async def start_import(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(ContactStates.waiting_csv_file)
    await callback.message.edit_text(
        "📥 فایل CSV مخاطبین رو ارسال کن.\n\n"
        "فایل باید حتما یک ستون به اسم <code>email</code> داشته باشه.\n"
        "ستون <code>name</code> اختیاریه.",
        reply_markup=back_btn("menu:contacts"),
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(ContactStates.waiting_csv_file, F.document)
async def receive_csv_file(message: Message, state: FSMContext, admin, bot):
    if admin is None:
        return
    doc = message.document
    if not doc.file_name.lower().endswith(".csv"):
        await message.answer("❌ لطفا فقط فایل با پسوند .csv بفرست.")
        return

    file = await bot.get_file(doc.file_id)
    file_bytes = await bot.download_file(file.file_path)
    rows, errors = parse_contacts_csv(file_bytes.read())

    added, duplicates = 0, 0
    session = get_session()
    try:
        for row in rows:
            if session.query(Contact).filter_by(email=row["email"]).first():
                duplicates += 1
                continue
            session.add(Contact(email=row["email"], full_name=row["name"], source="csv_import"))
            added += 1
        session.commit()
    finally:
        session.close()

    result_text = f"✅ ایمپورت تمام شد.\n\n➕ اضافه شد: {added}\n🔁 تکراری (رد شد): {duplicates}"
    if errors:
        error_preview = "\n".join(errors[:10])
        result_text += f"\n⚠️ خطاها ({len(errors)}):\n{error_preview}"
        if len(errors) > 10:
            result_text += f"\n... و {len(errors) - 10} خطای دیگه"

    await state.clear()
    await message.answer(result_text, reply_markup=contacts_menu_kb())


@router.message(ContactStates.waiting_csv_file)
async def wrong_csv_upload(message: Message):
    await message.answer("❌ باید یک فایل CSV بفرستی، نه متن.")


# ---------------------------------------------------------------------------
# جستجو
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "contacts:search")
async def start_search(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(ContactStates.waiting_search_query)
    await callback.message.edit_text(
        "🔍 بخشی از ایمیل یا اسم مخاطب رو بفرست:",
        reply_markup=back_btn("menu:contacts"),
    )
    await callback.answer()


@router.message(ContactStates.waiting_search_query)
async def do_search(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    q = message.text.strip()
    session = get_session()
    try:
        results = session.query(Contact).filter(
            (Contact.email.ilike(f"%{q}%")) | (Contact.full_name.ilike(f"%{q}%"))
        ).limit(20).all()

        if not results:
            await message.answer("چیزی پیدا نشد.", reply_markup=contacts_menu_kb())
            await state.clear()
            return

        lines = []
        for c in results:
            status = "✅" if c.is_subscribed else "❌"
            lines.append(f"{status} {c.email} — {c.full_name or 'بدون نام'} (id:{c.id})")
        text = "نتایج جستجو:\n\n" + "\n".join(lines)
    finally:
        session.close()

    await state.clear()
    await message.answer(text, reply_markup=contacts_menu_kb())


# ---------------------------------------------------------------------------
# لیست صفحه‌بندی‌شده
# ---------------------------------------------------------------------------

@router.callback_query(F.data.startswith("contacts:list:"))
async def list_contacts(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    page = int(callback.data.split(":")[2])

    session = get_session()
    try:
        total = session.query(Contact).count()
        contacts = (
            session.query(Contact)
            .order_by(Contact.created_at.desc())
            .offset(page * PAGE_SIZE)
            .limit(PAGE_SIZE + 1)
            .all()
        )
        has_next = len(contacts) > PAGE_SIZE
        contacts = contacts[:PAGE_SIZE]

        if not contacts:
            await callback.message.edit_text("هیچ مخاطبی ثبت نشده.", reply_markup=contacts_menu_kb())
            await callback.answer()
            return

        lines = [f"👥 مخاطبین (صفحه {page+1}) — کل: {total}\n"]
        for c in contacts:
            status = "✅" if c.is_subscribed else "❌"
            lines.append(f"{status} <code>{c.id}</code> | {c.email} | {c.full_name or '-'}")
        lines.append("\nبرای مدیریت هر مخاطب، آیدیش رو با /contact بفرست. مثال: /contact 5")
        text = "\n".join(lines)
    finally:
        session.close()

    await callback.message.edit_text(
        text, reply_markup=pagination_kb("contacts:list", page, has_next), parse_mode="HTML"
    )
    await callback.answer()


@router.message(F.text.regexp(r"^/contact\s+(\d+)$"))
async def contact_detail(message: Message, admin):
    if admin is None:
        return
    contact_id = int(message.text.split()[1])
    session = get_session()
    try:
        c = session.query(Contact).get(contact_id)
        if not c:
            await message.answer("مخاطبی با این آیدی پیدا نشد.")
            return
        tags = ", ".join(t.name for t in c.tags) or "بدون تگ"
        status = "مشترک ✅" if c.is_subscribed else "لغو اشتراک ❌"
        text = (
            f"👤 <b>جزئیات مخاطب</b>\n\n"
            f"آیدی: {c.id}\nایمیل: {c.email}\nنام: {c.full_name or '-'}\n"
            f"وضعیت: {status}\nتگ‌ها: {tags}\nمنبع: {c.source}\n"
            f"تاریخ افزودن: {c.created_at.strftime('%Y-%m-%d')}"
        )
    finally:
        session.close()

    await message.answer(text, reply_markup=contact_detail_kb(contact_id, 0), parse_mode="HTML")


@router.callback_query(F.data.startswith("contact:delete:"))
async def confirm_delete_contact(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    _, _, contact_id, page = callback.data.split(":")
    await callback.message.edit_text(
        "❗️مطمئنی می‌خوای این مخاطب حذف بشه؟",
        reply_markup=yes_no_kb("delete_contact", f"{contact_id}:{page}"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("yn:yes:delete_contact:"))
async def do_delete_contact(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    contact_id, page = callback.data.split(":")[3].split(":")
    session = get_session()
    try:
        c = session.query(Contact).get(int(contact_id))
        if c:
            session.delete(c)
            session.commit()
    finally:
        session.close()
    await callback.message.edit_text("🗑 مخاطب حذف شد.", reply_markup=contacts_menu_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("yn:no:delete_contact:"))
async def cancel_delete_contact(callback: CallbackQuery):
    await callback.message.edit_text("لغو شد.", reply_markup=contacts_menu_kb())
    await callback.answer()


# ---------------------------------------------------------------------------
# خروجی CSV
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "contacts:export")
async def export_contacts(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)

    session = get_session()
    try:
        contacts = session.query(Contact).all()
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(["email", "name", "subscribed", "tags", "created_at"])
        for c in contacts:
            tags = ";".join(t.name for t in c.tags)
            writer.writerow([c.email, c.full_name, c.is_subscribed, tags, c.created_at.strftime("%Y-%m-%d")])
        file_bytes = buffer.getvalue().encode("utf-8-sig")
    finally:
        session.close()

    await callback.message.answer_document(
        BufferedInputFile(file_bytes, filename="contacts_export.csv"),
        caption=f"📤 خروجی کامل مخاطبین ({len(contacts)} مورد)",
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# مدیریت تگ‌ها
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "contacts:tags")
async def list_tags(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    session = get_session()
    try:
        tags = session.query(Tag).all()
        lines = [f"🏷 {t.name} ({len(t.contacts)} مخاطب)" for t in tags] or ["هنوز تگی ساخته نشده."]
    finally:
        session.close()
    await callback.message.edit_text(
        "🏷 تگ‌های موجود:\n\n" + "\n".join(lines) +
        "\n\nبرای افزودن تگ به یک مخاطب، اول جزئیاتش رو با /contact <آیدی> باز کن.",
        reply_markup=back_btn("menu:contacts"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("contact:tag:"))
async def start_add_tag(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    _, _, contact_id, page = callback.data.split(":")
    await state.set_state(ContactStates.waiting_tag_to_add)
    await state.update_data(contact_id=contact_id, page=page)
    await callback.message.edit_text("نام تگ رو بفرست (اگه وجود نداشته باشه ساخته میشه):")
    await callback.answer()


@router.message(ContactStates.waiting_tag_to_add)
async def do_add_tag(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    tag_name = message.text.strip()
    data = await state.get_data()
    session = get_session()
    try:
        contact = session.query(Contact).get(int(data["contact_id"]))
        tag = session.query(Tag).filter_by(name=tag_name).first()
        if not tag:
            tag = Tag(name=tag_name)
            session.add(tag)
            session.flush()
        if tag not in contact.tags:
            contact.tags.append(tag)
        session.commit()
    finally:
        session.close()
    await state.clear()
    await message.answer(f"✅ تگ «{tag_name}» اضافه شد.", reply_markup=contacts_menu_kb())
