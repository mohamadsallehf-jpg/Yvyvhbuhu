"""
هندلر شروع کار با ربات + نمایش منوی اصلی پنل ادمین
"""
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from keyboards import main_menu_kb
from models import Admin

router = Router(name="start")


@router.message(Command("start"))
async def cmd_start(message: Message, admin: Admin | None, state: FSMContext):
    await state.clear()
    if admin is None:
        await message.answer(
            "⛔️ دسترسی شما مجاز نیست.\n"
            "این ربات فقط مخصوص مدیریت فروشگاهه و آیدی شما تو لیست ادمین‌ها نیست.\n"
            f"آیدی عددی شما: <code>{message.from_user.id}</code>\n"
            "اگه صاحب ربات هستی، این آیدی رو باید تو فایل .env به عنوان SUPER_ADMIN_TELEGRAM_ID بذاری.",
            parse_mode="HTML",
        )
        return

    await message.answer(
        f"سلام {admin.display_name or ''} 👋\n\n"
        "به پنل مدیریت ربات ایمیل‌مارکتینگ فروشگاه خوش اومدی.\n"
        "از منوی زیر بخش موردنظرت رو انتخاب کن:",
        reply_markup=main_menu_kb(admin.role == "super_admin"),
    )


@router.callback_query(F.data == "menu:main")
async def show_main_menu(callback: CallbackQuery, admin: Admin | None, state: FSMContext):
    await state.clear()
    if admin is None:
        await callback.answer("دسترسی مجاز نیست.", show_alert=True)
        return
    await callback.message.edit_text(
        "منوی اصلی پنل مدیریت:",
        reply_markup=main_menu_kb(admin.role == "super_admin"),
    )
    await callback.answer()
