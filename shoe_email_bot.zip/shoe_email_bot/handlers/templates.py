"""
مدیریت قالب‌های ایمیل: ساخت، لیست، ویرایش، حذف
از تگ‌های {name} و {email} برای شخصی‌سازی متن استفاده میشه
"""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from database import get_session
from keyboards import back_btn, template_detail_kb, templates_menu_kb, yes_no_kb
from models import Template
from states import TemplateStates

router = Router(name="templates")


@router.callback_query(F.data == "menu:templates")
async def templates_menu(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await callback.message.edit_text("📝 مدیریت قالب‌های ایمیل:", reply_markup=templates_menu_kb())
    await callback.answer()


# ---------------------------------------------------------------------------
# ساخت قالب جدید
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "templates:add")
async def start_add_template(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(TemplateStates.waiting_name)
    await callback.message.edit_text(
        "📝 یک اسم برای قالب انتخاب کن (فقط برای شناسایی خودت، مثلا «تخفیف پاییزه»):",
        reply_markup=back_btn("menu:templates"),
    )
    await callback.answer()


@router.message(TemplateStates.waiting_name)
async def receive_template_name(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    await state.update_data(name=message.text.strip())
    await state.set_state(TemplateStates.waiting_subject)
    await message.answer(
        "✉️ موضوع (subject) ایمیل رو بفرست.\n"
        "می‌تونی از {name} برای اسم مخاطب استفاده کنی. مثال:\n"
        "«{name} عزیز، یک تخفیف ویژه منتظرته!»"
    )


@router.message(TemplateStates.waiting_subject)
async def receive_template_subject(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    await state.update_data(subject=message.text.strip())
    await state.set_state(TemplateStates.waiting_html_body)
    await message.answer(
        "📄 حالا متن اصلی ایمیل رو بفرست (میشه HTML هم باشه).\n"
        "تگ‌های {name} و {email} در متن هم قابل استفاده‌ست.\n\n"
        "مثال ساده:\n"
        "<b>{name} عزیز</b><br>از خرید شما در فروشگاه کفش ما متشکریم!<br>"
        "کد تخفیف: <b>SHOE20</b>"
    )


@router.message(TemplateStates.waiting_html_body)
async def receive_template_body(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    data = await state.get_data()
    session = get_session()
    try:
        template = Template(name=data["name"], subject=data["subject"], html_body=message.html_text or message.text)
        session.add(template)
        session.commit()
    finally:
        session.close()

    await state.clear()
    await message.answer(f"✅ قالب «{data['name']}» ساخته شد.", reply_markup=templates_menu_kb())


# ---------------------------------------------------------------------------
# لیست و جزئیات
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "templates:list")
async def list_templates(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    session = get_session()
    try:
        templates = session.query(Template).order_by(Template.created_at.desc()).all()
        if not templates:
            await callback.message.edit_text("هنوز هیچ قالبی ساخته نشده.", reply_markup=templates_menu_kb())
            await callback.answer()
            return
        lines = [f"<code>{t.id}</code> — {t.name}" for t in templates]
        text = "📝 قالب‌های موجود:\n\n" + "\n".join(lines) + "\n\nبرای مشاهده جزئیات: /template <آیدی>"
    finally:
        session.close()
    await callback.message.edit_text(text, reply_markup=back_btn("menu:templates"), parse_mode="HTML")
    await callback.answer()


@router.message(F.text.regexp(r"^/template\s+(\d+)$"))
async def template_detail(message: Message, admin):
    if admin is None:
        return
    template_id = int(message.text.split()[1])
    session = get_session()
    try:
        t = session.query(Template).get(template_id)
        if not t:
            await message.answer("قالبی با این آیدی پیدا نشد.")
            return
        preview = t.html_body[:500] + ("..." if len(t.html_body) > 500 else "")
        text = f"📝 <b>{t.name}</b>\n\nموضوع: {t.subject}\n\nپیش‌نمایش متن:\n{preview}"
    finally:
        session.close()
    await message.answer(text, reply_markup=template_detail_kb(template_id), parse_mode="HTML")


@router.callback_query(F.data.startswith("template:edit_subject:"))
async def start_edit_subject(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    template_id = callback.data.split(":")[2]
    await state.set_state(TemplateStates.waiting_edit_field)
    await state.update_data(template_id=template_id, field="subject")
    await callback.message.edit_text("موضوع جدید رو بفرست:")
    await callback.answer()


@router.callback_query(F.data.startswith("template:edit_body:"))
async def start_edit_body(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    template_id = callback.data.split(":")[2]
    await state.set_state(TemplateStates.waiting_edit_field)
    await state.update_data(template_id=template_id, field="html_body")
    await callback.message.edit_text("متن جدید رو بفرست:")
    await callback.answer()


@router.message(TemplateStates.waiting_edit_field)
async def save_edit_field(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    data = await state.get_data()
    session = get_session()
    try:
        t = session.query(Template).get(int(data["template_id"]))
        if data["field"] == "subject":
            t.subject = message.text.strip()
        else:
            t.html_body = message.html_text or message.text
        session.commit()
    finally:
        session.close()
    await state.clear()
    await message.answer("✅ قالب به‌روزرسانی شد.", reply_markup=templates_menu_kb())


@router.callback_query(F.data.startswith("template:delete:"))
async def confirm_delete_template(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    template_id = callback.data.split(":")[2]
    await callback.message.edit_text(
        "❗️مطمئنی می‌خوای این قالب حذف بشه؟ (کمپین‌هایی که ازش استفاده کردن دست نمی‌خوره)",
        reply_markup=yes_no_kb("delete_template", template_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("yn:yes:delete_template:"))
async def do_delete_template(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    template_id = callback.data.split(":")[3]
    session = get_session()
    try:
        t = session.query(Template).get(int(template_id))
        if t:
            session.delete(t)
            session.commit()
    finally:
        session.close()
    await callback.message.edit_text("🗑 قالب حذف شد.", reply_markup=templates_menu_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("yn:no:delete_template:"))
async def cancel_delete_template(callback: CallbackQuery):
    await callback.message.edit_text("لغو شد.", reply_markup=templates_menu_kb())
    await callback.answer()
