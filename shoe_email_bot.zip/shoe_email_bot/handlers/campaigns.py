"""
مدیریت کمپین‌ها: ساخت، انتخاب قالب/تگ/حساب SMTP، زمان‌بندی، ارسال (با تایید PIN
برای عملیات حساس)، و گزارش‌گیری
"""
import asyncio
import datetime

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from database import get_session
from email_sender import run_campaign
from keyboards import (back_btn, campaign_detail_kb, campaigns_menu_kb,
                        schedule_choice_kb, smtp_pick_kb, tag_filter_kb,
                        template_pick_kb)
from models import (ActivityLog, Campaign, CampaignStatus, Contact, SMTPAccount,
                     Tag, Template)
from scheduler import cancel_scheduled_campaign, schedule_campaign
from states import CampaignStates, SecurityStates
from utils import verify_pin

router = Router(name="campaigns")


def _log_action(session, admin_id, action, detail=""):
    session.add(ActivityLog(admin_id=admin_id, action=action, detail=detail))
    session.commit()


@router.callback_query(F.data == "menu:campaigns")
async def campaigns_menu(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await callback.message.edit_text("📤 مدیریت کمپین‌ها:", reply_markup=campaigns_menu_kb())
    await callback.answer()


# ---------------------------------------------------------------------------
# ساخت کمپین جدید
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "campaigns:add")
async def start_add_campaign(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)

    session = get_session()
    try:
        templates = session.query(Template).all()
        if not templates:
            await callback.message.edit_text(
                "⚠️ اول باید حداقل یک قالب ایمیل بسازی.", reply_markup=campaigns_menu_kb()
            )
            await callback.answer()
            return
        smtp_accounts = session.query(SMTPAccount).filter_by(is_active=True).all()
        if not smtp_accounts:
            await callback.message.edit_text(
                "⚠️ اول باید حداقل یک حساب SMTP فعال تنظیم کنی.", reply_markup=campaigns_menu_kb()
            )
            await callback.answer()
            return
    finally:
        session.close()

    await state.set_state(CampaignStates.waiting_name)
    await callback.message.edit_text("📤 یک اسم برای این کمپین انتخاب کن:", reply_markup=back_btn("menu:campaigns"))
    await callback.answer()


@router.message(CampaignStates.waiting_name)
async def receive_campaign_name(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    await state.update_data(name=message.text.strip())
    session = get_session()
    try:
        templates = session.query(Template).all()
        text = "📝 کدوم قالب ایمیل استفاده بشه؟"
        kb = template_pick_kb(templates)
    finally:
        session.close()
    await state.set_state(CampaignStates.choosing_template)
    await message.answer(text, reply_markup=kb)


@router.callback_query(CampaignStates.choosing_template, F.data.startswith("pick_template:"))
async def pick_template(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    template_id = callback.data.split(":")[1]
    await state.update_data(template_id=template_id)

    session = get_session()
    try:
        tags = session.query(Tag).all()
    finally:
        session.close()

    await state.set_state(CampaignStates.choosing_tag_filter)
    await callback.message.edit_text(
        "🎯 این کمپین برای کدوم گروه ارسال بشه؟", reply_markup=tag_filter_kb(tags)
    )
    await callback.answer()


@router.callback_query(CampaignStates.choosing_tag_filter, F.data.startswith("pick_tag:"))
async def pick_tag(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    tag_value = callback.data.split(":", 1)[1]
    tag_filter = None if tag_value == "__all__" else tag_value
    await state.update_data(tag_filter=tag_filter)

    session = get_session()
    try:
        smtp_accounts = session.query(SMTPAccount).filter_by(is_active=True).all()
    finally:
        session.close()

    await state.set_state(CampaignStates.choosing_smtp_account)
    await callback.message.edit_text(
        "⚙️ از کدوم حساب SMTP ارسال بشه؟", reply_markup=smtp_pick_kb(smtp_accounts)
    )
    await callback.answer()


@router.callback_query(CampaignStates.choosing_smtp_account, F.data.startswith("pick_smtp:"))
async def pick_smtp(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    smtp_id = callback.data.split(":")[1]
    data = await state.get_data()

    session = get_session()
    try:
        campaign = Campaign(
            name=data["name"],
            template_id=int(data["template_id"]),
            smtp_account_id=int(smtp_id),
            tag_filter=data.get("tag_filter"),
            status=CampaignStatus.DRAFT,
            created_by_admin_id=admin.id,
        )
        session.add(campaign)
        session.commit()
        campaign_id = campaign.id
        _log_action(session, admin.id, "create_campaign", f"campaign_id={campaign_id}, name={data['name']}")
    finally:
        session.close()

    await state.clear()
    await callback.message.edit_text(
        f"✅ کمپین «{data['name']}» ساخته شد (پیش‌نویس).\n"
        "حالا می‌تونی از لیست کمپین‌ها اونو ارسال یا زمان‌بندی کنی.",
        reply_markup=campaigns_menu_kb(),
    )
    await callback.answer()


# ---------------------------------------------------------------------------
# لیست و جزئیات کمپین
# ---------------------------------------------------------------------------

STATUS_LABELS = {
    "draft": "📝 پیش‌نویس",
    "scheduled": "⏰ زمان‌بندی‌شده",
    "sending": "🚀 در حال ارسال",
    "paused": "⏸ متوقف‌شده",
    "completed": "✅ تکمیل‌شده",
    "failed": "❌ ناموفق",
}


@router.callback_query(F.data == "campaigns:list")
async def list_campaigns(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    session = get_session()
    try:
        campaigns = session.query(Campaign).order_by(Campaign.created_at.desc()).limit(30).all()
        if not campaigns:
            await callback.message.edit_text("هنوز هیچ کمپینی ساخته نشده.", reply_markup=campaigns_menu_kb())
            await callback.answer()
            return
        lines = [
            f"<code>{c.id}</code> — {c.name} — {STATUS_LABELS.get(c.status.value, c.status.value)}"
            for c in campaigns
        ]
        text = "📤 کمپین‌ها:\n\n" + "\n".join(lines) + "\n\nبرای جزئیات: /campaign <آیدی>"
    finally:
        session.close()
    await callback.message.edit_text(text, reply_markup=back_btn("menu:campaigns"), parse_mode="HTML")
    await callback.answer()


@router.message(F.text.regexp(r"^/campaign\s+(\d+)$"))
async def campaign_detail(message: Message, admin):
    if admin is None:
        return
    campaign_id = int(message.text.split()[1])
    session = get_session()
    try:
        c = session.query(Campaign).get(campaign_id)
        if not c:
            await message.answer("کمپینی با این آیدی پیدا نشد.")
            return
        text = (
            f"📤 <b>{c.name}</b>\n\n"
            f"وضعیت: {STATUS_LABELS.get(c.status.value, c.status.value)}\n"
            f"قالب: {c.template.name}\n"
            f"گروه هدف: {c.tag_filter or 'همه مخاطبین فعال'}\n"
            f"حساب SMTP: {c.smtp_account.name}\n"
            f"مخاطبین هدف: {c.total_recipients}\n"
            f"ارسال موفق: {c.sent_count} | ناموفق: {c.failed_count}\n"
        )
        if c.scheduled_at:
            text += f"زمان ارسال: {c.scheduled_at.strftime('%Y-%m-%d %H:%M')}\n"
        status = c.status.value
    finally:
        session.close()

    await message.answer(text, reply_markup=campaign_detail_kb(campaign_id, status), parse_mode="HTML")


@router.callback_query(F.data.startswith("campaign:report:"))
async def campaign_report(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    campaign_id = int(callback.data.split(":")[2])
    session = get_session()
    try:
        c = session.query(Campaign).get(campaign_id)
        if not c:
            await callback.answer("پیدا نشد.", show_alert=True)
            return
        rate = f"{(c.sent_count / c.total_recipients * 100):.1f}%" if c.total_recipients else "0%"
        text = (
            f"📊 <b>گزارش کمپین «{c.name}»</b>\n\n"
            f"کل مخاطبین هدف: {c.total_recipients}\n"
            f"✅ ارسال موفق: {c.sent_count}\n"
            f"❌ ناموفق: {c.failed_count}\n"
            f"نرخ موفقیت: {rate}\n"
        )
        if c.started_at:
            text += f"شروع: {c.started_at.strftime('%Y-%m-%d %H:%M')}\n"
        if c.finished_at:
            text += f"پایان: {c.finished_at.strftime('%Y-%m-%d %H:%M')}\n"
    finally:
        session.close()
    await callback.message.edit_text(text, reply_markup=back_btn("campaigns:list"), parse_mode="HTML")
    await callback.answer()


# ---------------------------------------------------------------------------
# ارسال / زمان‌بندی (با تایید PIN برای جلوگیری از ارسال اشتباهی)
# ---------------------------------------------------------------------------

async def _needs_pin(admin) -> bool:
    return bool(admin.pin_code)


async def _start_send_flow(callback: CallbackQuery, state: FSMContext, admin, campaign_id: str):
    if await _needs_pin(admin):
        await state.set_state(SecurityStates.waiting_pin_verify)
        await state.update_data(pending_action="send_now", campaign_id=campaign_id)
        await callback.message.edit_text("🔐 برای تایید ارسال، PIN کد خودت رو بفرست:")
        await callback.answer()
        return

    await _execute_send_now(callback, admin, int(campaign_id))


@router.callback_query(F.data.startswith("campaign:send_now:"))
async def request_send_now(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    campaign_id = callback.data.split(":")[2]
    await _start_send_flow(callback, state, admin, campaign_id)


@router.callback_query(F.data.startswith("campaign:schedule:"))
async def choose_schedule(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    campaign_id = callback.data.split(":")[2]
    await callback.message.edit_text(
        "⏰ زمان ارسال رو انتخاب کن:", reply_markup=schedule_choice_kb(int(campaign_id))
    )
    await callback.answer()


@router.callback_query(F.data.startswith("schedule_now:"))
async def schedule_now_redirect(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    campaign_id = callback.data.split(":")[1]
    await _start_send_flow(callback, state, admin, campaign_id)


@router.callback_query(F.data.startswith("schedule_custom:"))
async def request_custom_datetime(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    campaign_id = callback.data.split(":")[1]
    await state.set_state(CampaignStates.waiting_custom_datetime)
    await state.update_data(campaign_id=campaign_id)
    await callback.message.edit_text(
        "🕐 تاریخ و ساعت ارسال رو به این فرمت بفرست (به وقت سرور/UTC):\n"
        "<code>1404-07-20 18:30</code> یا <code>2026-10-12 18:30</code>",
        parse_mode="HTML",
    )
    await callback.answer()


@router.message(CampaignStates.waiting_custom_datetime)
async def receive_custom_datetime(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    text = message.text.strip()
    try:
        run_at = datetime.datetime.strptime(text, "%Y-%m-%d %H:%M")
    except ValueError:
        await message.answer("❌ فرمت درست نیست. مثال درست: 2026-10-12 18:30")
        return

    if run_at <= datetime.datetime.now():
        await message.answer("❌ این زمان گذشته. یه زمان آینده بفرست.")
        return

    data = await state.get_data()
    campaign_id = int(data["campaign_id"])

    if await _needs_pin(admin):
        await state.update_data(pending_action="schedule", run_at=run_at.isoformat())
        await state.set_state(SecurityStates.waiting_pin_verify)
        await message.answer("🔐 برای تایید زمان‌بندی، PIN کد خودت رو بفرست:")
        return

    await _finalize_schedule(message, admin, campaign_id, run_at)
    await state.clear()


@router.message(SecurityStates.waiting_pin_verify)
async def verify_pin_and_act(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    data = await state.get_data()
    entered_pin = message.text.strip()

    if not admin.pin_code or not verify_pin(entered_pin, admin.pin_code):
        await message.answer("❌ PIN اشتباهه. عملیات لغو شد.")
        await state.clear()
        return

    action = data.get("pending_action")
    campaign_id = int(data.get("campaign_id"))

    if action == "send_now":
        await _execute_send_now(message, admin, campaign_id)
    elif action == "schedule":
        run_at = datetime.datetime.fromisoformat(data["run_at"])
        await _finalize_schedule(message, admin, campaign_id, run_at)

    await state.clear()


async def _execute_send_now(event, admin, campaign_id: int):
    session = get_session()
    try:
        campaign = session.query(Campaign).get(campaign_id)
        campaign.status = CampaignStatus.SENDING
        session.commit()
        _log_action(session, admin.id, "send_campaign_now", f"campaign_id={campaign_id}")
    finally:
        session.close()

    target = event.message if isinstance(event, CallbackQuery) else event
    status_msg = await target.answer("🚀 ارسال کمپین شروع شد... این پیام هر چند ثانیه آپدیت میشه.")

    async def progress(sent, failed, total):
        try:
            await status_msg.edit_text(
                f"🚀 در حال ارسال...\n\n✅ ارسال شده: {sent}\n❌ ناموفق: {failed}\n🎯 کل: {total}"
            )
        except Exception:
            pass

    asyncio.create_task(_run_and_notify(campaign_id, status_msg, progress))

    if isinstance(event, CallbackQuery):
        await event.answer()


async def _run_and_notify(campaign_id, status_msg, progress_cb):
    await run_campaign(campaign_id, progress_callback=progress_cb)
    session = get_session()
    try:
        c = session.query(Campaign).get(campaign_id)
        final_text = (
            f"✅ کمپین «{c.name}» تمام شد.\n\n"
            f"ارسال موفق: {c.sent_count}\nناموفق: {c.failed_count}\nکل مخاطبین: {c.total_recipients}"
        )
    finally:
        session.close()
    try:
        await status_msg.edit_text(final_text)
    except Exception:
        pass


async def _finalize_schedule(event, admin, campaign_id: int, run_at: datetime.datetime):
    session = get_session()
    try:
        campaign = session.query(Campaign).get(campaign_id)
        campaign.status = CampaignStatus.SCHEDULED
        campaign.scheduled_at = run_at
        session.commit()
        _log_action(session, admin.id, "schedule_campaign", f"campaign_id={campaign_id}, run_at={run_at}")
    finally:
        session.close()

    schedule_campaign(campaign_id, run_at)
    await event.answer(f"⏰ کمپین برای {run_at.strftime('%Y-%m-%d %H:%M')} زمان‌بندی شد.")


@router.callback_query(F.data.startswith("campaign:cancel_schedule:"))
async def cancel_schedule(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    campaign_id = int(callback.data.split(":")[2])
    cancel_scheduled_campaign(campaign_id)
    session = get_session()
    try:
        c = session.query(Campaign).get(campaign_id)
        c.status = CampaignStatus.DRAFT
        c.scheduled_at = None
        session.commit()
        _log_action(session, admin.id, "cancel_schedule", f"campaign_id={campaign_id}")
    finally:
        session.close()
    await callback.message.edit_text("❌ زمان‌بندی لغو شد. کمپین به حالت پیش‌نویس برگشت.", reply_markup=campaigns_menu_kb())
    await callback.answer()
