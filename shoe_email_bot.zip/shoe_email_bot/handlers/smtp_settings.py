"""
مدیریت حساب‌های SMTP: افزودن، لیست، تست اتصال، فعال/غیرفعال کردن، حذف
پسورد همیشه رمزنگاری‌شده ذخیره میشه (هیچوقت plain-text نه تو دیتابیس نه تو لاگ)
"""
import aiosmtplib

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from database import get_session
from keyboards import back_btn, smtp_detail_kb, smtp_menu_kb, yes_no_kb
from models import ActivityLog, SMTPAccount
from states import SMTPStates
from utils import decrypt_password, encrypt_password, is_valid_email

router = Router(name="smtp_settings")


def _require_super_admin(admin) -> bool:
    return admin is not None and admin.role == "super_admin"


@router.callback_query(F.data == "menu:smtp")
async def smtp_menu(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    await callback.message.edit_text("⚙️ مدیریت حساب‌های SMTP:", reply_markup=smtp_menu_kb())
    await callback.answer()


# ---------------------------------------------------------------------------
# افزودن حساب SMTP جدید (فلوی چند مرحله‌ای)
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "smtp:add")
async def start_add_smtp(callback: CallbackQuery, state: FSMContext, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    await state.set_state(SMTPStates.waiting_name)
    await callback.message.edit_text(
        "یک اسم برای این حساب SMTP انتخاب کن (مثلا «جیمیل اصلی»):",
        reply_markup=back_btn("menu:smtp"),
    )
    await callback.answer()


@router.message(SMTPStates.waiting_name)
async def smtp_recv_name(message: Message, state: FSMContext, admin):
    await state.update_data(name=message.text.strip())
    await state.set_state(SMTPStates.waiting_host)
    await message.answer(
        "🌐 آدرس SMTP host رو بفرست.\n"
        "مثال جیمیل: smtp.gmail.com"
    )


@router.message(SMTPStates.waiting_host)
async def smtp_recv_host(message: Message, state: FSMContext, admin):
    await state.update_data(host=message.text.strip())
    await state.set_state(SMTPStates.waiting_port)
    await message.answer("🔌 پورت SMTP رو بفرست (معمولا 587):")


@router.message(SMTPStates.waiting_port)
async def smtp_recv_port(message: Message, state: FSMContext, admin):
    if not message.text.strip().isdigit():
        await message.answer("❌ پورت باید عدد باشه. دوباره بفرست:")
        return
    await state.update_data(port=int(message.text.strip()))
    await state.set_state(SMTPStates.waiting_username)
    await message.answer("👤 نام کاربری SMTP (معمولا خود آدرس ایمیل) رو بفرست:")


@router.message(SMTPStates.waiting_username)
async def smtp_recv_username(message: Message, state: FSMContext, admin):
    await state.update_data(username=message.text.strip())
    await state.set_state(SMTPStates.waiting_password)
    await message.answer(
        "🔑 پسورد یا App Password رو بفرست.\n"
        "⚠️ برای جیمیل حتما از «App Password» استفاده کن، نه پسورد اصلی اکانت.\n"
        "این پیام بعد از ذخیره‌شدن خودکار پاک میشه."
    )


@router.message(SMTPStates.waiting_password)
async def smtp_recv_password(message: Message, state: FSMContext, admin):
    await state.update_data(password=message.text.strip())
    try:
        await message.delete()
    except Exception:
        pass
    await state.set_state(SMTPStates.waiting_from_name)
    await message.answer("🏷 نام فرستنده که مشتری می‌بینه رو بفرست (مثلا «فروشگاه کفش X»):")


@router.message(SMTPStates.waiting_from_name)
async def smtp_recv_from_name(message: Message, state: FSMContext, admin):
    await state.update_data(from_name=message.text.strip())
    await state.set_state(SMTPStates.waiting_from_email)
    await message.answer("📧 ایمیل فرستنده (from) رو بفرست:")


@router.message(SMTPStates.waiting_from_email)
async def smtp_recv_from_email(message: Message, state: FSMContext, admin):
    email = message.text.strip()
    if not is_valid_email(email):
        await message.answer("❌ ایمیل معتبر نیست. دوباره بفرست:")
        return
    await state.update_data(from_email=email)
    await state.set_state(SMTPStates.waiting_daily_limit)
    await message.answer(
        "📊 سقف ارسال روزانه این حساب چقدر باشه؟ (عدد بفرست، پیشنهاد برای جیمیل معمولی: 300)"
    )


@router.message(SMTPStates.waiting_daily_limit)
async def smtp_recv_daily_limit(message: Message, state: FSMContext, admin):
    if not message.text.strip().isdigit():
        await message.answer("❌ باید عدد باشه. دوباره بفرست:")
        return
    await state.update_data(daily_limit=int(message.text.strip()))
    await state.set_state(SMTPStates.waiting_rate_limit)
    await message.answer(
        "⏱ چند ایمیل در هر دقیقه ارسال بشه؟ (پیشنهاد: 15 تا 20 برای جلوگیری از فلگ اسپم)"
    )


@router.message(SMTPStates.waiting_rate_limit)
async def smtp_recv_rate_limit(message: Message, state: FSMContext, admin):
    if not message.text.strip().isdigit():
        await message.answer("❌ باید عدد باشه. دوباره بفرست:")
        return

    data = await state.get_data()
    session = get_session()
    try:
        account = SMTPAccount(
            name=data["name"],
            host=data["host"],
            port=data["port"],
            username=data["username"],
            encrypted_password=encrypt_password(data["password"]),
            from_name=data.get("from_name", ""),
            from_email=data["from_email"],
            daily_limit=data["daily_limit"],
            rate_limit_per_minute=int(message.text.strip()),
        )
        session.add(account)
        session.add(ActivityLog(admin_id=admin.id, action="add_smtp_account", detail=data["name"]))
        session.commit()
    finally:
        session.close()

    await state.clear()
    await message.answer(
        f"✅ حساب SMTP «{data['name']}» اضافه شد.\n"
        "پیشنهاد میشه از دکمه «تست اتصال» مطمئن بشی درست کار می‌کنه.",
        reply_markup=smtp_menu_kb(),
    )


# ---------------------------------------------------------------------------
# لیست، تست اتصال، فعال/غیرفعال، حذف
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "smtp:list")
async def list_smtp(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    session = get_session()
    try:
        accounts = session.query(SMTPAccount).all()
        if not accounts:
            await callback.message.edit_text("هیچ حساب SMTP ثبت نشده.", reply_markup=smtp_menu_kb())
            await callback.answer()
            return
        lines = []
        for a in accounts:
            status = "✅ فعال" if a.is_active else "⏸ غیرفعال"
            lines.append(f"<code>{a.id}</code> — {a.name} ({a.host}) — {status}")
        text = "⚙️ حساب‌های SMTP:\n\n" + "\n".join(lines) + "\n\nبرای مدیریت هرکدوم: /smtp <آیدی>"
    finally:
        session.close()
    await callback.message.edit_text(text, reply_markup=back_btn("menu:smtp"), parse_mode="HTML")
    await callback.answer()


@router.message(F.text.regexp(r"^/smtp\s+(\d+)$"))
async def smtp_detail(message: Message, admin):
    if not _require_super_admin(admin):
        return
    smtp_id = int(message.text.split()[1])
    session = get_session()
    try:
        a = session.query(SMTPAccount).get(smtp_id)
        if not a:
            await message.answer("پیدا نشد.")
            return
        text = (
            f"⚙️ <b>{a.name}</b>\n\n"
            f"هاست: {a.host}:{a.port}\nیوزرنیم: {a.username}\n"
            f"فرستنده: {a.from_name} &lt;{a.from_email}&gt;\n"
            f"سقف روزانه: {a.daily_limit} | امروز ارسال شده: {a.sent_today}\n"
            f"نرخ ارسال: {a.rate_limit_per_minute} در دقیقه\n"
            f"وضعیت: {'فعال ✅' if a.is_active else 'غیرفعال ⏸'}"
        )
        is_active = a.is_active
    finally:
        session.close()
    await message.answer(text, reply_markup=smtp_detail_kb(smtp_id, is_active), parse_mode="HTML")


@router.callback_query(F.data.startswith("smtp:test:"))
async def test_smtp_connection(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    smtp_id = int(callback.data.split(":")[2])
    await callback.answer("در حال تست اتصال...")

    session = get_session()
    try:
        a = session.query(SMTPAccount).get(smtp_id)
        if not a:
            return
        host, port, username = a.host, a.port, a.username
        password = decrypt_password(a.encrypted_password)
        use_tls = a.use_tls
    finally:
        session.close()

    try:
        smtp = aiosmtplib.SMTP(hostname=host, port=port, timeout=15)
        await smtp.connect()
        if use_tls:
            await smtp.starttls()
        await smtp.login(username, password)
        await smtp.quit()
        await callback.message.answer("✅ اتصال و لاگین موفق بود! این حساب آماده ارسال هست.")
    except Exception as e:
        await callback.message.answer(f"❌ اتصال ناموفق بود:\n<code>{str(e)[:300]}</code>", parse_mode="HTML")


@router.callback_query(F.data.startswith("smtp:toggle:"))
async def toggle_smtp(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    smtp_id = int(callback.data.split(":")[2])
    session = get_session()
    try:
        a = session.query(SMTPAccount).get(smtp_id)
        a.is_active = not a.is_active
        session.add(ActivityLog(admin_id=admin.id, action="toggle_smtp", detail=f"id={smtp_id}, active={a.is_active}"))
        session.commit()
        new_status = a.is_active
    finally:
        session.close()
    await callback.answer("وضعیت تغییر کرد.")
    await callback.message.edit_text(
        f"وضعیت حساب به‌روزرسانی شد: {'فعال ✅' if new_status else 'غیرفعال ⏸'}",
        reply_markup=smtp_detail_kb(smtp_id, new_status),
    )


@router.callback_query(F.data.startswith("smtp:delete:"))
async def confirm_delete_smtp(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    smtp_id = callback.data.split(":")[2]
    await callback.message.edit_text(
        "❗️حذف این حساب SMTP باعث میشه کمپین‌های وابسته بهش دیگه قابل ارسال نباشن. مطمئنی؟",
        reply_markup=yes_no_kb("delete_smtp", smtp_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("yn:yes:delete_smtp:"))
async def do_delete_smtp(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    smtp_id = callback.data.split(":")[3]
    session = get_session()
    try:
        a = session.query(SMTPAccount).get(int(smtp_id))
        if a:
            session.delete(a)
            session.add(ActivityLog(admin_id=admin.id, action="delete_smtp", detail=f"id={smtp_id}"))
            session.commit()
    finally:
        session.close()
    await callback.message.edit_text("🗑 حساب SMTP حذف شد.", reply_markup=smtp_menu_kb())
    await callback.answer()


@router.callback_query(F.data.startswith("yn:no:delete_smtp:"))
async def cancel_delete_smtp(callback: CallbackQuery):
    await callback.message.edit_text("لغو شد.", reply_markup=smtp_menu_kb())
    await callback.answer()
