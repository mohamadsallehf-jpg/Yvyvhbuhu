"""
داشبورد - نمای کلی از وضعیت سیستم
"""
import datetime

from aiogram import F, Router
from aiogram.types import CallbackQuery

from database import get_session
from keyboards import back_btn
from models import Campaign, CampaignStatus, Contact, SendLog, SendStatus, SMTPAccount

router = Router(name="dashboard")


@router.callback_query(F.data == "menu:dashboard")
async def show_dashboard(callback: CallbackQuery, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)

    session = get_session()
    try:
        total_contacts = session.query(Contact).count()
        subscribed = session.query(Contact).filter_by(is_subscribed=True).count()
        unsubscribed = total_contacts - subscribed

        today_start = datetime.datetime.combine(datetime.date.today(), datetime.time.min)
        sent_today = session.query(SendLog).filter(
            SendLog.status == SendStatus.SENT, SendLog.sent_at >= today_start
        ).count()
        failed_today = session.query(SendLog).filter(
            SendLog.status == SendStatus.FAILED, SendLog.sent_at >= today_start
        ).count()

        active_campaigns = session.query(Campaign).filter(
            Campaign.status.in_([CampaignStatus.SENDING, CampaignStatus.SCHEDULED])
        ).count()
        total_campaigns = session.query(Campaign).count()

        smtp_accounts = session.query(SMTPAccount).filter_by(is_active=True).all()
        smtp_lines = "\n".join(
            f"  • {a.name}: {a.sent_today}/{a.daily_limit} امروز" for a in smtp_accounts
        ) or "  هیچ حساب SMTP فعالی وجود نداره ⚠️"

        text = (
            "📊 <b>داشبورد سیستم</b>\n\n"
            f"👥 مخاطبین: <b>{total_contacts}</b> کل | ✅ {subscribed} مشترک | ❌ {unsubscribed} لغو اشتراک\n\n"
            f"📤 امروز: <b>{sent_today}</b> ارسال موفق | {failed_today} ناموفق\n\n"
            f"🚀 کمپین‌ها: {total_campaigns} کل | {active_campaigns} در حال اجرا/زمان‌بندی\n\n"
            f"⚙️ حساب‌های SMTP فعال:\n{smtp_lines}"
        )
    finally:
        session.close()

    await callback.message.edit_text(text, reply_markup=back_btn(), parse_mode="HTML")
    await callback.answer()
