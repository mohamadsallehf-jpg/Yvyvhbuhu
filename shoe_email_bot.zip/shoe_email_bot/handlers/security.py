"""
امنیت و مدیریت ادمین‌ها: افزودن/حذف ادمین، تنظیم PIN برای تایید عملیات حساس،
مشاهده لاگ کامل فعالیت‌ها
"""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from database import get_session
from keyboards import back_btn, security_menu_kb, yes_no_kb
from models import ActivityLog, Admin, AdminRole
from states import SecurityStates
from utils import hash_pin

router = Router(name="security")

LOG_PAGE_SIZE = 15


def _require_super_admin(admin) -> bool:
    return admin is not None and admin.role == "super_admin"


@router.callback_query(F.data == "menu:security")
async def security_menu(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    await callback.message.edit_text("🔐 امنیت و مدیریت ادمین‌ها:", reply_markup=security_menu_kb())
    await callback.answer()


# ---------------------------------------------------------------------------
# لیست ادمین‌ها
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "security:admins")
async def list_admins(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    session = get_session()
    try:
        admins = session.query(Admin).all()
        lines = []
        for a in admins:
            role_label = "👑 سوپرادمین" if a.role == AdminRole.SUPER_ADMIN else "🧑‍💼 اپراتور"
            status = "فعال ✅" if a.is_active else "غیرفعال ⏸"
            lines.append(f"<code>{a.telegram_id}</code> — {a.display_name or '-'} — {role_label} — {status}")
        text = "👤 لیست ادمین‌ها:\n\n" + "\n".join(lines)
    finally:
        session.close()
    await callback.message.edit_text(text, reply_markup=back_btn("menu:security"), parse_mode="HTML")
    await callback.answer()


# ---------------------------------------------------------------------------
# افزودن ادمین جدید
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "security:add_admin")
async def start_add_admin(callback: CallbackQuery, state: FSMContext, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    await state.set_state(SecurityStates.waiting_new_admin_id)
    await callback.message.edit_text(
        "🆔 آیدی عددی تلگرام ادمین جدید رو بفرست.\n"
        "(کاربر مدنظر می‌تونه آیدیشو از @userinfobot بگیره):",
        reply_markup=back_btn("menu:security"),
    )
    await callback.answer()


@router.message(SecurityStates.waiting_new_admin_id)
async def receive_new_admin_id(message: Message, state: FSMContext, admin):
    if not _require_super_admin(admin):
        return
    text = message.text.strip()
    if not text.isdigit():
        await message.answer("❌ باید یک عدد (آیدی تلگرام) باشه. دوباره بفرست:")
        return

    new_id = int(text)
    session = get_session()
    try:
        if session.query(Admin).filter_by(telegram_id=new_id).first():
            await message.answer("⚠️ این کاربر از قبل ادمینه.", reply_markup=security_menu_kb())
            await state.clear()
            return
        new_admin = Admin(telegram_id=new_id, role=AdminRole.OPERATOR, is_active=True)
        session.add(new_admin)
        session.add(ActivityLog(admin_id=admin.id, action="add_admin", detail=f"new_admin_id={new_id}"))
        session.commit()
    finally:
        session.close()

    await state.clear()
    await message.answer(
        f"✅ ادمین جدید (آیدی {new_id}) با نقش «اپراتور» اضافه شد.\n"
        "این فرد فقط به مخاطبین/قالب‌ها/کمپین‌ها دسترسی داره، نه تنظیمات SMTP و امنیت.",
        reply_markup=security_menu_kb(),
    )


# ---------------------------------------------------------------------------
# تنظیم PIN برای تایید عملیات حساس (ارسال/زمان‌بندی کمپین)
# ---------------------------------------------------------------------------

@router.callback_query(F.data == "security:set_pin")
async def start_set_pin(callback: CallbackQuery, state: FSMContext, admin):
    if admin is None:
        return await callback.answer("دسترسی مجاز نیست.", show_alert=True)
    await state.set_state(SecurityStates.waiting_pin_setup)
    await callback.message.edit_text(
        "🔑 یک کد PIN عددی ۴ تا ۸ رقمی بفرست.\n"
        "این کد قبل از هر ارسال یا زمان‌بندی کمپین ازت پرسیده میشه تا از ارسال اشتباهی جلوگیری بشه.",
        reply_markup=back_btn("menu:security"),
    )
    await callback.answer()


@router.message(SecurityStates.waiting_pin_setup)
async def receive_pin_setup(message: Message, state: FSMContext, admin):
    if admin is None:
        return
    pin = message.text.strip()
    if not pin.isdigit() or not (4 <= len(pin) <= 8):
        await message.answer("❌ PIN باید فقط عدد و بین ۴ تا ۸ رقم باشه. دوباره بفرست:")
        return

    session = get_session()
    try:
        a = session.query(Admin).get(admin.id)
        a.pin_code = hash_pin(pin)
        session.commit()
    finally:
        session.close()

    try:
        await message.delete()
    except Exception:
        pass

    await state.clear()
    await message.answer("✅ PIN با موفقیت تنظیم شد. از این به بعد برای ارسال کمپین ازت پرسیده میشه.", reply_markup=security_menu_kb())


# ---------------------------------------------------------------------------
# لاگ فعالیت‌ها
# ---------------------------------------------------------------------------

@router.callback_query(F.data.startswith("security:logs:"))
async def show_logs(callback: CallbackQuery, admin):
    if not _require_super_admin(admin):
        return await callback.answer("فقط سوپرادمین به این بخش دسترسی داره.", show_alert=True)
    page = int(callback.data.split(":")[2])

    session = get_session()
    try:
        logs = (
            session.query(ActivityLog)
            .order_by(ActivityLog.created_at.desc())
            .offset(page * LOG_PAGE_SIZE)
            .limit(LOG_PAGE_SIZE)
            .all()
        )
        if not logs:
            await callback.message.edit_text("لاگی ثبت نشده.", reply_markup=back_btn("menu:security"))
            await callback.answer()
            return

        lines = []
        for log in logs:
            admin_name = log.admin.display_name or log.admin.telegram_id if log.admin else "سیستم"
            lines.append(f"🕐 {log.created_at.strftime('%m-%d %H:%M')} | {admin_name} | {log.action} | {log.detail}")
        text = "📜 لاگ فعالیت‌ها:\n\n" + "\n".join(lines)
    finally:
        session.close()

    await callback.message.edit_text(text, reply_markup=back_btn("menu:security"))
    await callback.answer()
