"""
میان‌افزار امنیتی: هر آپدیت (پیام یا کلیک دکمه) قبل از رسیدن به هندلر،
از فیلتر «آیا این کاربر ادمین فعال ثبت‌شده هست؟» رد میشه.
این تضمین می‌کنه که غریبه‌ها به هیچ بخشی از پنل دسترسی نداشته باشن.
"""
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update

from database import get_session
from models import Admin


class AdminAuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = data.get("event_from_user")
        if user is None:
            return await handler(event, data)

        session = get_session()
        try:
            admin = session.query(Admin).filter_by(telegram_id=user.id, is_active=True).first()
            data["admin"] = admin
            data["is_admin"] = admin is not None
        finally:
            session.close()

        return await handler(event, data)
