"""
تنظیمات اصلی پروژه - همه چیز از فایل .env خونده میشه
"""
import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
SUPER_ADMIN_TELEGRAM_ID = int(os.getenv("SUPER_ADMIN_TELEGRAM_ID", "0"))
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///shoe_bot.db")
DEFAULT_RATE_LIMIT_PER_MINUTE = int(os.getenv("DEFAULT_RATE_LIMIT_PER_MINUTE", "20"))

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN در فایل .env تنظیم نشده است.")
if not SUPER_ADMIN_TELEGRAM_ID:
    raise RuntimeError("SUPER_ADMIN_TELEGRAM_ID در فایل .env تنظیم نشده است.")
if not ENCRYPTION_KEY:
    raise RuntimeError(
        "ENCRYPTION_KEY تنظیم نشده. با دستور زیر یکی بساز:\n"
        "python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
    )
