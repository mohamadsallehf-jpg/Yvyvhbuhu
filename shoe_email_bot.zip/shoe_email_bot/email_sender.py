"""
موتور ارسال ایمیل - ارسال ناهمزمان با محدودیت نرخ (rate limit) و تلاش مجدد در صورت خطا
"""
import asyncio
import datetime
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import aiosmtplib

from database import get_session
from models import Campaign, CampaignStatus, Contact, SendLog, SendStatus, SMTPAccount, Tag
from utils import append_unsubscribe_footer, decrypt_password, render_template

logger = logging.getLogger("email_sender")

MAX_RETRIES = 3
RETRY_DELAY_SECONDS = 5


async def _send_single_email(smtp_account: SMTPAccount, to_email: str, subject: str, html_body: str) -> tuple[bool, str]:
    """یک ایمیل رو با retry ارسال می‌کنه. برمی‌گردونه (موفق بود؟, پیام خطا)"""
    password = decrypt_password(smtp_account.encrypted_password)
    from_header = f"{smtp_account.from_name} <{smtp_account.from_email}>" if smtp_account.from_name else smtp_account.from_email

    message = MIMEMultipart("alternative")
    message["From"] = from_header
    message["To"] = to_email
    message["Subject"] = subject
    message.attach(MIMEText(html_body, "html", "utf-8"))

    last_error = ""
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            await aiosmtplib.send(
                message,
                hostname=smtp_account.host,
                port=smtp_account.port,
                username=smtp_account.username,
                password=password,
                start_tls=smtp_account.use_tls,
                timeout=30,
            )
            return True, ""
        except Exception as e:  # noqa: BLE001 - می‌خوایم هر خطای SMTP رو بگیریم و لاگ کنیم
            last_error = str(e)
            logger.warning("تلاش %s برای ارسال به %s ناموفق بود: %s", attempt, to_email, last_error)
            if attempt < MAX_RETRIES:
                await asyncio.sleep(RETRY_DELAY_SECONDS)

    return False, last_error


def _reset_daily_counter_if_needed(session, smtp_account: SMTPAccount):
    today = datetime.datetime.utcnow().strftime("%Y-%m-%d")
    if smtp_account.last_reset_date != today:
        smtp_account.sent_today = 0
        smtp_account.last_reset_date = today
        session.commit()


async def run_campaign(campaign_id: int, progress_callback=None):
    """
    موتور اصلی ارسال کمپین:
    - مخاطبین هدف رو با توجه به تگ فیلتر می‌کنه
    - مشترکین لغو-اشتراک‌کرده رو حذف می‌کنه
    - با رعایت rate limit و daily limit حساب SMTP ارسال می‌کنه
    - هر نتیجه رو در SendLog ثبت می‌کنه
    - progress_callback(sent, failed, total) بعد از هر ایمیل صدا زده میشه (برای آپدیت پیام تلگرام)
    """
    session = get_session()
    try:
        campaign = session.query(Campaign).get(campaign_id)
        if not campaign:
            return

        smtp_account = campaign.smtp_account
        if not smtp_account or not smtp_account.is_active:
            campaign.status = CampaignStatus.FAILED
            session.commit()
            return

        query = session.query(Contact).filter(Contact.is_subscribed.is_(True))
        if campaign.tag_filter:
            query = query.join(Contact.tags).filter(Tag.name == campaign.tag_filter)
        contacts = query.all()

        campaign.status = CampaignStatus.SENDING
        campaign.total_recipients = len(contacts)
        campaign.started_at = datetime.datetime.utcnow()
        session.commit()

        rate_limit = max(1, smtp_account.rate_limit_per_minute)
        delay_between_emails = 60.0 / rate_limit

        sent_count = 0
        failed_count = 0
        hit_daily_limit = False

        for contact in contacts:
            _reset_daily_counter_if_needed(session, smtp_account)

            existing_log = session.query(SendLog).filter_by(
                campaign_id=campaign.id, contact_id=contact.id
            ).first()
            if existing_log and existing_log.status == SendStatus.SENT:
                continue  # قبلا با موفقیت ارسال شده - از ارسال دوباره جلوگیری میشه

            if smtp_account.sent_today >= smtp_account.daily_limit:
                logger.info("سقف ارسال روزانه حساب SMTP '%s' پر شد؛ باقی مخاطبین برای فردا می‌مونن.", smtp_account.name)
                hit_daily_limit = True
                break

            subject, body = render_template(
                campaign.template.html_body, campaign.template.subject,
                contact.full_name, contact.email,
            )
            body = append_unsubscribe_footer(body, contact.unsubscribe_token)

            success, error = await _send_single_email(smtp_account, contact.email, subject, body)

            log_entry = existing_log or SendLog(campaign_id=campaign.id, contact_id=contact.id)
            log_entry.status = SendStatus.SENT if success else SendStatus.FAILED
            log_entry.error_message = error
            log_entry.sent_at = datetime.datetime.utcnow()
            session.add(log_entry)

            if success:
                sent_count += 1
                smtp_account.sent_today += 1
            else:
                failed_count += 1

            campaign.sent_count = sent_count
            campaign.failed_count = failed_count
            session.commit()

            if progress_callback:
                await progress_callback(sent_count, failed_count, len(contacts))

            await asyncio.sleep(delay_between_emails)

        if hit_daily_limit:
            # سقف روزانه‌ی حساب SMTP پر شده - کمپین متوقف میشه تا ادمین فردا
            # دستی ادامه بده (یا حساب SMTP دیگه‌ای انتخاب کنه)
            campaign.status = CampaignStatus.PAUSED
        else:
            campaign.status = CampaignStatus.COMPLETED
            campaign.finished_at = datetime.datetime.utcnow()
        session.commit()

    finally:
        session.close()
