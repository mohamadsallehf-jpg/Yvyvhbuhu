"""
راه‌اندازی دیتابیس و session ها
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session

from config import DATABASE_URL
from models import Base, Admin, AdminRole

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = scoped_session(sessionmaker(bind=engine, autoflush=False, autocommit=False))


def init_db(super_admin_telegram_id: int):
    """جداول رو می‌سازه و اگه ادمین اصلی وجود نداشت، اضافه‌اش می‌کنه"""
    Base.metadata.create_all(engine)
    session = SessionLocal()
    try:
        existing = session.query(Admin).filter_by(telegram_id=super_admin_telegram_id).first()
        if not existing:
            admin = Admin(
                telegram_id=super_admin_telegram_id,
                display_name="مالک ربات",
                role=AdminRole.SUPER_ADMIN,
                is_active=True,
            )
            session.add(admin)
            session.commit()
    finally:
        session.close()


def get_session():
    """یک session جدید برمی‌گردونه - باید بعد از استفاده close بشه"""
    return SessionLocal()
