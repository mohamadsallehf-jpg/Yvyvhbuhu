"""
کیبوردهای اینلاین پنل ادمین
"""
from aiogram.types import InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def main_menu_kb(is_super_admin: bool):
    b = InlineKeyboardBuilder()
    b.button(text="📊 داشبورد", callback_data="menu:dashboard")
    b.button(text="👥 مخاطبین", callback_data="menu:contacts")
    b.button(text="📝 قالب‌های ایمیل", callback_data="menu:templates")
    b.button(text="📤 کمپین‌ها", callback_data="menu:campaigns")
    if is_super_admin:
        b.button(text="⚙️ تنظیمات SMTP", callback_data="menu:smtp")
        b.button(text="🔐 امنیت و ادمین‌ها", callback_data="menu:security")
    b.adjust(2)
    return b.as_markup()


def back_btn(target="menu:main"):
    b = InlineKeyboardBuilder()
    b.button(text="🔙 بازگشت", callback_data=target)
    return b.as_markup()


def contacts_menu_kb():
    b = InlineKeyboardBuilder()
    b.button(text="➕ افزودن مخاطب", callback_data="contacts:add")
    b.button(text="📥 ایمپورت CSV", callback_data="contacts:import")
    b.button(text="🔍 جستجو", callback_data="contacts:search")
    b.button(text="📋 لیست مخاطبین", callback_data="contacts:list:0")
    b.button(text="📤 خروجی CSV", callback_data="contacts:export")
    b.button(text="🏷 مدیریت تگ‌ها", callback_data="contacts:tags")
    b.button(text="🔙 بازگشت", callback_data="menu:main")
    b.adjust(2, 2, 2, 1)
    return b.as_markup()


def contact_detail_kb(contact_id: int, page: int):
    b = InlineKeyboardBuilder()
    b.button(text="🏷 افزودن تگ", callback_data=f"contact:tag:{contact_id}:{page}")
    b.button(text="🗑 حذف", callback_data=f"contact:delete:{contact_id}:{page}")
    b.button(text="🔙 بازگشت به لیست", callback_data=f"contacts:list:{page}")
    b.adjust(2, 1)
    return b.as_markup()


def pagination_kb(prefix: str, page: int, has_next: bool):
    b = InlineKeyboardBuilder()
    row = []
    if page > 0:
        row.append(InlineKeyboardButton(text="⬅️ قبلی", callback_data=f"{prefix}:{page-1}"))
    if has_next:
        row.append(InlineKeyboardButton(text="بعدی ➡️", callback_data=f"{prefix}:{page+1}"))
    if row:
        b.row(*row)
    b.button(text="🔙 بازگشت", callback_data="menu:contacts")
    b.adjust(len(row) if row else 1, 1)
    return b.as_markup()


def templates_menu_kb():
    b = InlineKeyboardBuilder()
    b.button(text="➕ ساخت قالب جدید", callback_data="templates:add")
    b.button(text="📋 لیست قالب‌ها", callback_data="templates:list")
    b.button(text="🔙 بازگشت", callback_data="menu:main")
    b.adjust(1)
    return b.as_markup()


def template_detail_kb(template_id: int):
    b = InlineKeyboardBuilder()
    b.button(text="✏️ ویرایش موضوع", callback_data=f"template:edit_subject:{template_id}")
    b.button(text="✏️ ویرایش متن", callback_data=f"template:edit_body:{template_id}")
    b.button(text="🗑 حذف قالب", callback_data=f"template:delete:{template_id}")
    b.button(text="🔙 بازگشت", callback_data="menu:templates")
    b.adjust(2, 1, 1)
    return b.as_markup()


def campaigns_menu_kb():
    b = InlineKeyboardBuilder()
    b.button(text="➕ کمپین جدید", callback_data="campaigns:add")
    b.button(text="📋 لیست کمپین‌ها", callback_data="campaigns:list")
    b.button(text="🔙 بازگشت", callback_data="menu:main")
    b.adjust(1)
    return b.as_markup()


def campaign_detail_kb(campaign_id: int, status: str):
    b = InlineKeyboardBuilder()
    if status == "draft":
        b.button(text="🚀 ارسال الان", callback_data=f"campaign:send_now:{campaign_id}")
        b.button(text="⏰ زمان‌بندی", callback_data=f"campaign:schedule:{campaign_id}")
    if status == "scheduled":
        b.button(text="❌ لغو زمان‌بندی", callback_data=f"campaign:cancel_schedule:{campaign_id}")
    if status == "paused":
        b.button(text="▶️ ادامه ارسال", callback_data=f"campaign:send_now:{campaign_id}")
    b.button(text="📊 گزارش کمپین", callback_data=f"campaign:report:{campaign_id}")
    b.button(text="🔙 بازگشت", callback_data="campaigns:list")
    b.adjust(2, 1, 1)
    return b.as_markup()


def template_pick_kb(templates):
    b = InlineKeyboardBuilder()
    for t in templates:
        b.button(text=t.name, callback_data=f"pick_template:{t.id}")
    b.button(text="🔙 لغو", callback_data="menu:campaigns")
    b.adjust(1)
    return b.as_markup()


def smtp_pick_kb(accounts):
    b = InlineKeyboardBuilder()
    for a in accounts:
        label = f"{a.name} ({a.sent_today}/{a.daily_limit} امروز)"
        b.button(text=label, callback_data=f"pick_smtp:{a.id}")
    b.button(text="🔙 لغو", callback_data="menu:campaigns")
    b.adjust(1)
    return b.as_markup()


def tag_filter_kb(tags):
    b = InlineKeyboardBuilder()
    b.button(text="👥 همه مخاطبین فعال", callback_data="pick_tag:__all__")
    for t in tags:
        b.button(text=f"🏷 {t.name}", callback_data=f"pick_tag:{t.name}")
    b.adjust(1)
    return b.as_markup()


def schedule_choice_kb(campaign_id: int):
    b = InlineKeyboardBuilder()
    b.button(text="🚀 همین الان", callback_data=f"schedule_now:{campaign_id}")
    b.button(text="🕐 زمان دلخواه", callback_data=f"schedule_custom:{campaign_id}")
    b.adjust(1)
    return b.as_markup()


def confirm_kb(action: str, entity_id):
    b = InlineKeyboardBuilder()
    b.button(text="✅ تایید", callback_data=f"confirm:{action}:{entity_id}")
    b.button(text="❌ انصراف", callback_data="menu:main")
    b.adjust(2)
    return b.as_markup()


def smtp_menu_kb():
    b = InlineKeyboardBuilder()
    b.button(text="➕ افزودن حساب SMTP", callback_data="smtp:add")
    b.button(text="📋 لیست حساب‌ها", callback_data="smtp:list")
    b.button(text="🔙 بازگشت", callback_data="menu:main")
    b.adjust(1)
    return b.as_markup()


def smtp_detail_kb(smtp_id: int, is_active: bool):
    b = InlineKeyboardBuilder()
    toggle_text = "⏸ غیرفعال کردن" if is_active else "▶️ فعال کردن"
    b.button(text=toggle_text, callback_data=f"smtp:toggle:{smtp_id}")
    b.button(text="🧪 تست اتصال", callback_data=f"smtp:test:{smtp_id}")
    b.button(text="🗑 حذف", callback_data=f"smtp:delete:{smtp_id}")
    b.button(text="🔙 بازگشت", callback_data="smtp:list")
    b.adjust(2, 1, 1)
    return b.as_markup()


def security_menu_kb():
    b = InlineKeyboardBuilder()
    b.button(text="👤 لیست ادمین‌ها", callback_data="security:admins")
    b.button(text="➕ افزودن ادمین", callback_data="security:add_admin")
    b.button(text="🔑 تنظیم/تغییر PIN من", callback_data="security:set_pin")
    b.button(text="📜 لاگ فعالیت‌ها", callback_data="security:logs:0")
    b.button(text="🔙 بازگشت", callback_data="menu:main")
    b.adjust(1)
    return b.as_markup()


def yes_no_kb(action: str, entity_id):
    b = InlineKeyboardBuilder()
    b.button(text="بله", callback_data=f"yn:yes:{action}:{entity_id}")
    b.button(text="خیر", callback_data=f"yn:no:{action}:{entity_id}")
    b.adjust(2)
    return b.as_markup()
