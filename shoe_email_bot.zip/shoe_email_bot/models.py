"""
مدل‌های دیتابیس - ساختار کامل داده‌های ربات
"""
import datetime
import enum
import secrets

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, ForeignKey, Integer,
    String, Text, UniqueConstraint
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


def now():
    return datetime.datetime.utcnow()


# ---------------------------------------------------------------------------
# ادمین‌ها و امنیت
# ---------------------------------------------------------------------------

class AdminRole(str, enum.Enum):
    SUPER_ADMIN = "super_admin"   # دسترسی کامل: مدیریت ادمین‌ها، SMTP، تنظیمات
    OPERATOR = "operator"         # مدیریت مخاطبین و کمپین‌ها، بدون تنظیمات حساس


class Admin(Base):
    __tablename__ = "admins"

    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True, nullable=False, index=True)
    display_name = Column(String(128), default="")
    role = Column(Enum(AdminRole), default=AdminRole.OPERATOR, nullable=False)
    is_active = Column(Boolean, default=True)
    pin_code = Column(String(128), nullable=True)  # هش شده - برای تایید عملیات حساس
    created_at = Column(DateTime, default=now)

    logs = relationship("ActivityLog", back_populates="admin")


class ActivityLog(Base):
    """لاگ کامل هر اقدام حساس ادمین‌ها - برای رهگیری امنیتی"""
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True)
    admin_id = Column(Integer, ForeignKey("admins.id"), nullable=True)
    action = Column(String(64), nullable=False)
    detail = Column(Text, default="")
    created_at = Column(DateTime, default=now)

    admin = relationship("Admin", back_populates="logs")


# ---------------------------------------------------------------------------
# مخاطبین و تگ‌ها
# ---------------------------------------------------------------------------

class Contact(Base):
    __tablename__ = "contacts"

    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(128), default="")
    is_subscribed = Column(Boolean, default=True)  # False یعنی از لیست خارج شده (unsubscribe)
    unsubscribe_token = Column(String(64), unique=True, default=lambda: secrets.token_urlsafe(24))
    source = Column(String(64), default="manual")  # manual / csv_import / bot_signup
    bounce_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)

    tags = relationship("Tag", secondary="contact_tags", back_populates="contacts")
    send_logs = relationship("SendLog", back_populates="contact")


class Tag(Base):
    __tablename__ = "tags"

    id = Column(Integer, primary_key=True)
    name = Column(String(64), unique=True, nullable=False)

    contacts = relationship("Contact", secondary="contact_tags", back_populates="tags")


class ContactTag(Base):
    __tablename__ = "contact_tags"

    contact_id = Column(Integer, ForeignKey("contacts.id"), primary_key=True)
    tag_id = Column(Integer, ForeignKey("tags.id"), primary_key=True)


# ---------------------------------------------------------------------------
# قالب‌های ایمیل
# ---------------------------------------------------------------------------

class Template(Base):
    __tablename__ = "templates"

    id = Column(Integer, primary_key=True)
    name = Column(String(128), nullable=False)
    subject = Column(String(255), nullable=False)
    html_body = Column(Text, nullable=False)
    created_at = Column(DateTime, default=now)
    updated_at = Column(DateTime, default=now, onupdate=now)

    campaigns = relationship("Campaign", back_populates="template")


# ---------------------------------------------------------------------------
# حساب‌های SMTP (میشه چند تا اضافه کرد تا حجم ارسال بالا بره و ریسک بلاک کم بشه)
# ---------------------------------------------------------------------------

class SMTPAccount(Base):
    __tablename__ = "smtp_accounts"

    id = Column(Integer, primary_key=True)
    name = Column(String(64), nullable=False)
    host = Column(String(255), nullable=False)
    port = Column(Integer, default=587)
    username = Column(String(255), nullable=False)
    encrypted_password = Column(Text, nullable=False)
    use_tls = Column(Boolean, default=True)
    from_name = Column(String(128), default="")
    from_email = Column(String(255), nullable=False)
    daily_limit = Column(Integer, default=300)
    rate_limit_per_minute = Column(Integer, default=20)
    sent_today = Column(Integer, default=0)
    last_reset_date = Column(String(10), default=lambda: now().strftime("%Y-%m-%d"))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)

    campaigns = relationship("Campaign", back_populates="smtp_account")


# ---------------------------------------------------------------------------
# کمپین‌ها و لاگ ارسال
# ---------------------------------------------------------------------------

class CampaignStatus(str, enum.Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    SENDING = "sending"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"


class Campaign(Base):
    __tablename__ = "campaigns"

    id = Column(Integer, primary_key=True)
    name = Column(String(128), nullable=False)
    template_id = Column(Integer, ForeignKey("templates.id"), nullable=False)
    smtp_account_id = Column(Integer, ForeignKey("smtp_accounts.id"), nullable=False)
    tag_filter = Column(String(64), nullable=True)  # اگر خالی باشه یعنی همه مخاطبین فعال
    status = Column(Enum(CampaignStatus), default=CampaignStatus.DRAFT)
    scheduled_at = Column(DateTime, nullable=True)
    total_recipients = Column(Integer, default=0)
    sent_count = Column(Integer, default=0)
    failed_count = Column(Integer, default=0)
    created_by_admin_id = Column(Integer, ForeignKey("admins.id"), nullable=True)
    created_at = Column(DateTime, default=now)
    started_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)

    template = relationship("Template", back_populates="campaigns")
    smtp_account = relationship("SMTPAccount", back_populates="campaigns")
    send_logs = relationship("SendLog", back_populates="campaign")


class SendStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    SKIPPED_UNSUBSCRIBED = "skipped_unsubscribed"


class SendLog(Base):
    __tablename__ = "send_logs"

    id = Column(Integer, primary_key=True)
    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=False)
    contact_id = Column(Integer, ForeignKey("contacts.id"), nullable=False)
    status = Column(Enum(SendStatus), default=SendStatus.PENDING)
    error_message = Column(Text, default="")
    sent_at = Column(DateTime, nullable=True)

    __table_args__ = (UniqueConstraint("campaign_id", "contact_id", name="uq_campaign_contact"),)

    campaign = relationship("Campaign", back_populates="send_logs")
    contact = relationship("Contact", back_populates="send_logs")
