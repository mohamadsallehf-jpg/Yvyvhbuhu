"""
زمان‌بند کمپین‌ها - با APScheduler کمپین‌های زمان‌بندی‌شده رو در زمان مقرر اجرا می‌کنه
"""
import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from database import get_session
from email_sender import run_campaign
from models import Campaign, CampaignStatus

logger = logging.getLogger("scheduler")
scheduler = AsyncIOScheduler()


def start_scheduler():
    scheduler.start()
    _reload_pending_campaigns()


def _reload_pending_campaigns():
    """موقع استارت مجدد ربات، کمپین‌های زمان‌بندی‌شده‌ی قبلی رو دوباره تو صف می‌ذاره"""
    session = get_session()
    try:
        pending = session.query(Campaign).filter_by(status=CampaignStatus.SCHEDULED).all()
        for campaign in pending:
            if campaign.scheduled_at:
                schedule_campaign(campaign.id, campaign.scheduled_at)
    finally:
        session.close()


def schedule_campaign(campaign_id: int, run_at):
    job_id = f"campaign_{campaign_id}"
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
    scheduler.add_job(
        run_campaign,
        trigger="date",
        run_date=run_at,
        args=[campaign_id],
        id=job_id,
        misfire_grace_time=3600,
    )
    logger.info("کمپین %s برای %s زمان‌بندی شد.", campaign_id, run_at)


def cancel_scheduled_campaign(campaign_id: int):
    job_id = f"campaign_{campaign_id}"
    if scheduler.get_job(job_id):
        scheduler.remove_job(job_id)
